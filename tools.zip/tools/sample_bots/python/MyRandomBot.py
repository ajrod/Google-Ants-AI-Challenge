#!/usr/bin/env python
from random import shuffle
from ants import *

class MyRandomBot:
    def __init__(self):
        
        self.destinations = []
    def do_turn(self, ants):
        for a_row, a_col in ants.my_ants():
            closestFood = ants.closest_food(a_row,a_col)            
            directions = AIM.keys() 
            if closestFood == None:
                shuffle(directions)
                for direction in directions:
                    (n_row, n_col) = ants.destination(a_row, a_col, direction)
                    if (not (n_row, n_col) in destinations and
                            ants.passable(n_row, n_col)):
                        ants.issue_order((a_row, a_col, direction))
                        self.destinations.append((n_row, n_col))
                        break
                else:
                    self.destinations.append((a_row, a_col))
            else:
                currentDirection = directions[0]
                (a, b) = ants.destination(a_row, a_col, currentDirection)
                minD = ants.distance(a, b, closestFood[0], closestFood[1])
                ct = 1
                while (ct < 4):
                    (n_row, n_col) = ants.destination(a_row, a_col, directions[ct])
                    d = ants.distance(n_row, n_col, closestFood[0], closestFood[1])
                    if (n_row, n_col) in self.destinations:
                        d = d * 10
                        
                    if (d <= minD and ants.passable(n_row, n_col)):
                        minD = d
                        currentDirection = directions[ct]
                        (a, b) = (n_row, n_col)
                    ct += 1
                    
                ants.issue_order((a_row, a_col, currentDirection))
                self.destinations.append((a, b))
                

if __name__ == '__main__':
    try:
        import psyco
        psyco.full()
    except ImportError:
        pass
    try:
        Ants.run(MyRandomBot())
    except KeyboardInterrupt:
        print('ctrl-c, leaving ...')
