            
AIM = {'n': (-1, 0),
       'e': (0, 1),
       's': (1, 0),
       'w': (0, -1)}

def Search(startState, goalState, ants):

    explored = []
    startPath = Path()
    startPath.end = startState
    frontier = [startPath]
    while len(frontier) != 0:
        
        selectedPath = aStar(frontier, ants, goalState)
        
        s = selectedPath.end
        explored.append(s)
        
        if (s == goalState):
            return selectedPath

        addToFrontier(s[0], s[1], 'n', selectedPath, frontier, explored, ants)
        addToFrontier(s[0], s[1], 's', selectedPath, frontier, explored, ants)
        addToFrontier(s[0], s[1], 'e', selectedPath, frontier, explored, ants)
        addToFrontier(s[0], s[1], 'w', selectedPath, frontier, explored, ants)
        
def addToFrontier(a, b, direction, selectedPath, frontier, explored, ants):
    (n_row, n_col) = ants.destination(a, b, direction)
    if ants.passable(n_row, n_col) and (n_row, n_col) not in explored:
        add = True
        ct = 0
        while (ct < len(frontier)):
            if frontier[ct].end == (n_row, n_col):
                add = False
                if frontier[ct].cost > selectedPath.cost + 1:
                    add = True
                    frontier.pop(ct)
                    ct -= 1
            ct += 1
        
        if (add):
            frontier.append(selectedPath.add(direction, (n_row, n_col)))
def aStar(frontier, ants, goalState):
    ct = 1
    d = f(frontier[0], ants, goalState)
    path = frontier[0]
    while (ct < len(frontier)):
        if f(frontier[ct], ants, goalState) < d:
            d = f(frontier[ct], ants, goalState)
            path = frontier[ct]
        ct += 1
    frontier.remove(path)
    return path

def f(p, ants, goalState):
    
    return p.cost + ants.distance(p.end[0], p.end[1], goalState[0], goalState[1])

class ants(object):
    
    def __init__(self):
        self.height = 5
        self.width = 5
        
    def destination(self, row, col, direction):
        d_row, d_col = AIM[direction]
        return ((row + d_row) % self.height, (col + d_col) % self.width) 
    def passable(self, row, col):
        if (row, col) == (2, 1):
            return False
        elif (row, col) == (3, 1):
            return False
        elif (row, col) == (2, 2):
            return False
        elif (row, col) == (2, 3):
            return False
        elif (row, col) == (3, 3):
            return False
        else:
            return True
    def distance(self, row1, col1, row2, col2):
        row1 = row1 % self.height
        row2 = row2 % self.height
        col1 = col1 % self.width
        col2 = col2 % self.width
        d_col = min(abs(col1 - col2), self.width - abs(col1 - col2))
        d_row = min(abs(row1 - row2), self.height - abs(row1 - row2))
        return d_col + d_row
class Path(object):
    
    def __init__(self):
        
        self.end = None
        self.sequence = ""
        self.cost = 0
        
    def add(self, action, end):
        p = Path()
        p.end = end
        p.sequence = self.sequence
        p.sequence += action
        p.cost = self.cost + 1
        return p

if __name__ == "__main__":
    start = (3,2)
    goal = (0,3)
    a = ants()
    s = Search(start, goal, a).sequence
    ct = 0
    (n_row, n_col) = (3, 2)
    print (3, 2)
    while ct < len(s):
        (n_row, n_col) = a.destination(n_row, n_col, s[ct])
        print (n_row, n_col)
        ct += 1